import Redis from "ioredis";

const redis = new Redis({
  host: process.env.REDIS_HOST || 'redis' ,
  port: process.env.REDIS_PORT || 6379
});

redis.on("connect", () => {
  console.log("✅ Redis connected successfully");
});

redis.on("error", (err) => {
  console.error("❌ Redis error:", err);
});

export default redis;
