-- ⚠️ Auto-generated rollback (review for complex schemas)
DROP TABLE IF EXISTS vehicle_applications CASCADE;