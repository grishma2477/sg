-- ⚠️ Auto-generated rollback (review for complex schemas)
DROP TABLE IF EXISTS driver_verifications CASCADE;