export const SafetyImpactFactory = {
  create({ rating, taps }) {
    //star impact
    const starImpactMap = {
      5: 2,
      4: 1,
      3: 0,
      2: -5,
      1: -10
    };

    const starImpact = starImpactMap[rating.stars] ?? 0;

    //positive impact  
    const positiveImpactRaw = taps
      .filter(t => t.category === "positive")
      .reduce((sum, t) => sum + t.pointValue, 0);

    const positiveImpact = Math.min(positiveImpactRaw, 6);

    // negative Impact 
    const negativeImpactRaw = taps
      .filter(t => t.category === "negative")
      .reduce((sum, t) => sum + Math.abs(t.pointValue), 0);

    const negativeImpact = -Math.min(negativeImpactRaw, 40);

    // Total impact either positive or negative but never both 
    let totalImpact = starImpact + positiveImpact + negativeImpact;

    //capping 
    totalImpact = Math.min(totalImpact, 8);
    totalImpact = Math.max(totalImpact, -50);

    return {
      starImpact,
      positiveImpact,
      negativeImpact,
      totalImpact
    };
  }
};
