import { safetyQueue } from "../infrastructure/queue/safetyQueue.js";
import { runSafetyWorker } from "../application/workers/runSafetyWorker.js";

console.log("🚦 Safety worker started");

safetyQueue.process(async (job) => {
  console.log("⚙️ Processing safety job for review:", job.data.review.id);
  await runSafetyWorker(job.data);
});
