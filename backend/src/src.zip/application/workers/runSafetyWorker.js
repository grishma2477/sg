import DriverSafetyModel from "../../models/driver/driver_safety_stats/DriverSafetyStats.js";
import SafetyAuditModel from "../../models/safety/SafetyAuditLog.js";
import { SafetyCalculationService } from "../services/SafetyCalculationService.js";

export async function runSafetyWorker({ review, reviewerRole }) {
  // Only rider → driver affects driver safety
  if (reviewerRole !== "rider") {
    console.log("ℹ️ No safety impact for reviewer role:", reviewerRole);
    return;
  }

  const safetyService = new SafetyCalculationService();
  const impact = safetyService.calculate(review);
console.log("👤 Reviewer role:", reviewerRole);
console.log("🎯 Target user:", review.targetUserId);

  // Fetch current points
  const stats = await DriverSafetyModel.findOne({
    driver_id: review.targetUserId
  });

  const before = stats.safety_points;
  const after = before + impact.totalImpact;

  // Update driver points
  await DriverSafetyModel.updateOne(
    { driver_id: review.targetUserId },
    { safety_points: after }
  );

  // Write audit log
  await SafetyAuditModel.create({
    review_id: review.id,
    before_points: before,
    after_points: after
  });
  console.log("📝 Audit log inserted for review:", review.id);

console.log("🧮 Calculated impact:", impact);
console.log("✅ Updated safety points:", before, "→", after);

  console.log("✅ Safety updated:", before, "→", after);
}
