// export class ReviewEligibilityValidator {
//   static validate({ rideSummary, hasReviewed }) {
//     if (!rideSummary.isPaid) {
//       throw new Error("RIDE_NOT_PAID");
//     }

//     if (hasReviewed) {
//       throw new Error("REVIEW_ALREADY_SUBMITTED");
//     }
//   }
// }
import { AppError } from "../../utils/AppError.js";
export class ReviewEligibilityValidator {
  static validate({ rideSummary, hasReviewed }) {
     if (!rideSummary.isPaid) {
      throw new AppError("RIDE_NOT_PAID", 400);
    }

    if (rideSummary.status !== "completed") {
      throw new AppError("RIDE_NOT_COMPLETED", 400);
    }

    if (hasReviewed) {
      throw new AppError("REVIEW_ALREADY_SUBMITTED", 409);
    }
  }
}
