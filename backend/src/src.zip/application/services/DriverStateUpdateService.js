import DriverModel from "../../models/driver/Driver.js";

const MAX_SAFETY = 100;
const MIN_SAFETY = -100;

export class DriverStateUpdateService {
  async apply({ driverId, totalImpact }) {
    const driver = await DriverModel.findById(driverId);

    const previousPoints = driver.safety_points || 0;
    let newPoints = previousPoints + totalImpact;

    /* GLOBAL SAFETY CAPPING */
    newPoints = Math.min(newPoints, MAX_SAFETY);
    newPoints = Math.max(newPoints, MIN_SAFETY);

    /* DRIVER STATUS LOGIC */
    let status = "active";

    if (newPoints <= -80) status = "suspended";
    else if (newPoints <= -50) status = "restricted";
    else if (newPoints >= 70) status = "priority";

    await DriverModel.findByIdAndUpdate(driverId, {
      safety_points: newPoints,
      status
    });

    return {
      previousPoints,
      newPoints,
      status
    };
  }
}
