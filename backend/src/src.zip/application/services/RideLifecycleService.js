import RideModel from "../../models/ride/Ride.js";
import redis from "../../infrastructure/redisClient.js";

export class RideLifecycleService {
  async createRide({ riderId, driverId }) {
    return RideModel.create({
      rider_id: riderId,
      driver_id: driverId,
      status: "created",
      is_paid: false
    });
  }

  async startRide({ rideId }) {
    return RideModel.findByIdAndUpdate(rideId, {
      status: "started"
    });
  }

  async completeRide({ rideId }) {
    const ride = await RideModel.findById(rideId);

    if (!ride) throw new Error("Ride not found");
    if (ride.status !== "started") {
      throw new Error("Ride must be started before completion");
    }

    const updated = await RideModel.findByIdAndUpdate(rideId, {
      status: "completed",
      is_paid: true
    });

    // 🔒 Enforce mandatory review for BOTH parties
    await redis.set(`pending_review:${ride.rider_id}`, rideId);
    await redis.set(`pending_review:${ride.driver_id}`, rideId);

    return updated;
  }
}
