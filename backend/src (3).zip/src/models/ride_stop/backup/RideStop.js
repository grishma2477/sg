// import { ModelManager } from '../../../database/utils/ModelManager.js';
// import { RideStopQueryManager } from './RideStopQueryManager.js';
// import { String } from '../../../utils/Constant.js';

// const RideStop = ModelManager.createModel(
//   RideStopQueryManager.createRideStopTableQuery,
//   String.RIDE_STOP_MODEL
// );

// export default RideStop;
