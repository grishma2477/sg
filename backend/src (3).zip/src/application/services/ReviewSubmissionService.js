

// import { ReviewEligibilityValidator } from "../validators/ReviewEligibilityValidator.js";
// import { RatingTapValidator } from "../validators/RatingTapValidator.js";
// import { ReviewFactory } from "../factories/ReviewFactory.js";

// import { withTransaction } from "../../infrastructure/transactions/withTransaction.js";
// import { safetyQueue } from "../../infrastructure/queue/safetyQueue.js";
// import redis from "../../infrastructure/redisClient.js";

// import ReviewModel from "../../models/review/Review.js";
// import DriverModel from "../../models/driver/Driver.js";
// import { AppError } from "../../utils/AppError.js";

// export class ReviewSubmissionService {
//   /**
//    * Submit a review for a completed ride
//    * 
//    * @param {Object} params
//    * @param {Object} params.rideSummary - Ride details
//    * @param {Object} params.rating - Rating object with stars
//    * @param {Array}  params.taps - Array of tap feedback
//    * @param {Object} params.currentUser - Authenticated user from JWT
//    */
//   async submit({ rideSummary, rating, taps, currentUser }) {

//     // ═══════════════════════════════════════════════════
//     // 1️⃣ CHECK IF USER ALREADY REVIEWED THIS RIDE
//     // ═══════════════════════════════════════════════════
//     const existingReview = await ReviewModel.findOne({
//       ride_id: rideSummary.rideId,
//       reviewer_id: currentUser.id
//     });

//     const hasReviewed = !!existingReview;

//     // ═══════════════════════════════════════════════════
//     // 2️⃣ VALIDATE ELIGIBILITY
//     // ═══════════════════════════════════════════════════
//     ReviewEligibilityValidator.validate({
//       rideSummary,
//       hasReviewed
//     });

//     RatingTapValidator.validate(rating, taps);

//     // ═══════════════════════════════════════════════════
//     // 3️⃣ DETERMINE REVIEWER/REVIEWEE DIRECTION
//     // ═══════════════════════════════════════════════════
//     let reviewerId;
//     let targetDriverId;  // The driver record ID
//     let targetUserId;    // The user_id of the target

//     console.log("DEBUG DRIVER REVIEW", {
//   tokenUserId: currentUser.id,
//   payloadDriverId: rideSummary.driverId
// });
//     if (currentUser.role === "rider") {
//       if (rideSummary.riderId !== currentUser.id) {
//         throw new AppError("RIDER_NOT_PART_OF_RIDE", 403);
//       }

//       reviewerId = currentUser.id;

//       // IMPORTANT: driverId from payload is ALREADY drivers.id
//       targetDriverId = rideSummary.driverId;

//       // Optional sanity check
//       const driver = await DriverModel.findById(targetDriverId);
//       if (!driver) {
//         throw new AppError("DRIVER_NOT_FOUND", 404);
//       }
//     }
//     else if (currentUser.role === "driver") {
//       // Driver → Rider (doesn't affect safety score)
//       if (rideSummary.driverId !== currentUser.id) {
//         throw new AppError("DRIVER_NOT_PART_OF_RIDE", 403);
//       }

//       reviewerId = currentUser.id;
//       targetUserId = rideSummary.riderId;

//       // For driver reviews, we still need a driver_id for the schema
//       // Use the current driver's record
//       // const driver = await DriverModel.findOne({ user_id: currentUser.id });
//       // if (!driver) {
//       //   throw new AppError("DRIVER_RECORD_NOT_FOUND", 404);
//       // }
//       // targetDriverId = driver.id;

//       // Resolve driver ONCE from current user
//       const driver = await DriverModel.findOne({ user_id: currentUser.id });
//       if (!driver) {
//         throw new AppError("DRIVER_RECORD_NOT_FOUND", 404);
//       }
//       targetDriverId = driver.id;

//     } else {
//       throw new AppError("ROLE_NOT_ALLOWED_TO_REVIEW", 403);
//     }

//     // ═══════════════════════════════════════════════════
//     // 4️⃣ CREATE DOMAIN REVIEW OBJECT
//     // ═══════════════════════════════════════════════════
//     const review = ReviewFactory.create({
//       rideId: rideSummary.rideId,
//       reviewerId,
//       driverId: targetDriverId,  
//       rating,
//       taps
//     });

//     // ═══════════════════════════════════════════════════
//     // 5️⃣ SEPARATE TAPS BY CATEGORY
//     // ═══════════════════════════════════════════════════
//     const positiveTaps = (taps || []).filter(t => t.category === "positive");
//     const negativeTaps = (taps || []).filter(t => t.category === "negative");
//     const hasSafetyConcern = negativeTaps.length > 0;

//     // ═══════════════════════════════════════════════════
//     // 6️⃣ SAVE TO DATABASE (TRANSACTION)
//     // ═══════════════════════════════════════════════════
//     await withTransaction(async (client) => {
//       await ReviewModel.create(
//         {
//           id: review.id,
//           ride_id: rideSummary.rideId,
//           reviewer_id: reviewerId,
//           reviewee_driver_id: targetDriverId,  // Correct column name
//           star_rating: rating.stars,            // Correct column name
//           positive_taps: JSON.stringify(positiveTaps),
//           negative_taps: JSON.stringify(negativeTaps),
//           has_safety_concern: hasSafetyConcern,
//           is_processed: false,
//           created_at: review.createdAt
//         },
//         client
//       );
//     });

//     console.log("✅ Review saved:", review.id);

//     // ═══════════════════════════════════════════════════
//     // 7️⃣ CLEAR PENDING REVIEW FLAG IN REDIS
//     // ═══════════════════════════════════════════════════
//     await redis.del(`pending_review:${reviewerId}`);
//     console.log("🔓 Cleared pending review for user:", reviewerId);

//     // ═══════════════════════════════════════════════════
//     // 8️⃣ QUEUE SAFETY CALCULATION (ASYNC)
//     // ═══════════════════════════════════════════════════
//     console.log("📤 Adding safety job to queue...");

//     await safetyQueue.add(
//       "process-safety-review",
//       {
//         review: {
//           id: review.id,
//           rideId: review.rideId,
//           reviewerId: review.reviewerId,
//           driverEntityId: targetDriverId, // ✅ drivers.id ONLY
//           rating: review.rating,
//           taps: review.taps
//         },
//         reviewerRole: currentUser.role
//       },
//       {
//         attempts: 3,
//         backoff: { type: "exponential", delay: 3000 },
//         removeOnComplete: true
//       }
//     );

//     console.log("✅ Safety job queued for review:", review.id);

//     // ═══════════════════════════════════════════════════
//     // 9️⃣ RETURN REVIEW
//     // ═══════════════════════════════════════════════════
//     return review;
//   }
// }

import { ReviewEligibilityValidator } from "../validators/ReviewEligibilityValidator.js";
import { RatingTapValidator } from "../validators/RatingTapValidator.js";
import { ReviewFactory } from "../factories/ReviewFactory.js";

import { withTransaction } from "../../infrastructure/transactions/withTransaction.js";
import { safetyQueue } from "../../infrastructure/queue/safetyQueue.js";
import redis from "../../infrastructure/redisClient.js";

import ReviewModel from "../../models/review/Review.js";
import DriverModel from "../../models/driver/Driver.js";
import { AppError } from "../../utils/AppError.js";

export class ReviewSubmissionService {
  async submit({ rideSummary, rating, taps, currentUser }) {

    /* ─────────────────────────────────────────────
       1️⃣ Prevent duplicate review by same user
    ───────────────────────────────────────────── */
    const existingReview = await ReviewModel.findOne({
      ride_id: rideSummary.rideId,
      reviewer_id: currentUser.id
    });

    if (existingReview) {
      throw new AppError("REVIEW_ALREADY_SUBMITTED", 409);
    }

    /* ─────────────────────────────────────────────
       2️⃣ Validate business rules
    ───────────────────────────────────────────── */
    ReviewEligibilityValidator.validate({ rideSummary });
    RatingTapValidator.validate(rating, taps);

    /* ─────────────────────────────────────────────
       3️⃣ Resolve direction & targets
    ───────────────────────────────────────────── */
    let reviewerId = currentUser.id;
    let revieweeDriverId = null;
    let revieweeUserId = null;
    let affectsSafety = false;

    // ───── Rider → Driver ─────
    if (currentUser.role === "rider") {
      if (rideSummary.riderId !== currentUser.id) {
        throw new AppError("RIDER_NOT_PART_OF_RIDE", 403);
      }

      // payload MUST send drivers.id
      const driver = await DriverModel.findById(rideSummary.driverId);
      if (!driver) {
        throw new AppError("DRIVER_NOT_FOUND", 404);
      }

      revieweeDriverId = driver.id;
      affectsSafety = true;
    }

    // ───── Driver → Rider ─────
    else if (currentUser.role === "driver") {
      const driver = await DriverModel.findOne({ user_id: currentUser.id });
      if (!driver) {
        throw new AppError("DRIVER_RECORD_NOT_FOUND", 404);
      }

      if (rideSummary.driverId !== driver.id) {
        throw new AppError("DRIVER_NOT_PART_OF_RIDE", 403);
      }

      revieweeUserId = rideSummary.riderId;
    }

    else {
      throw new AppError("ROLE_NOT_ALLOWED_TO_REVIEW", 403);
    }

    /* ─────────────────────────────────────────────
       4️⃣ Create domain review object
    ───────────────────────────────────────────── */
    const review = ReviewFactory.create({
      rideId: rideSummary.rideId,
      reviewerId,
      rating,
      taps
    });

    const positiveTaps = taps.filter(t => t.category === "positive");
    const negativeTaps = taps.filter(t => t.category === "negative");

    /* ─────────────────────────────────────────────
       5️⃣ Persist review (atomic)
    ───────────────────────────────────────────── */
    await withTransaction(async (client) => {
      await ReviewModel.create(
        {
          id: review.id,
          ride_id: rideSummary.rideId,
          reviewer_id: reviewerId,

          reviewee_driver_id: revieweeDriverId,
          reviewee_user_id: revieweeUserId,

          star_rating: rating.stars,
          positive_taps: JSON.stringify(positiveTaps),
          negative_taps: JSON.stringify(negativeTaps),
          has_safety_concern: negativeTaps.length > 0,
          is_processed: false
        },
        client
      );
    });

    /* ─────────────────────────────────────────────
       6️⃣ Redis cleanup
    ───────────────────────────────────────────── */
    await redis.del(`pending_review:${reviewerId}`);

    /* ─────────────────────────────────────────────
       7️⃣ Queue safety job (ONLY rider → driver)
    ───────────────────────────────────────────── */
    if (affectsSafety) {
      await safetyQueue.add(
        "process-safety-review",
        {
          review: {
            id: review.id,
            driverEntityId: revieweeDriverId,
            rating,
            taps
          },
          reviewerRole: "rider"
        },
        { removeOnComplete: true }
      );
    }

    /* ─────────────────────────────────────────────
       8️⃣ Return domain object
    ───────────────────────────────────────────── */
    return review;
  }
}
