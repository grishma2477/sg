import express from "express";
import { verifyuser, requireRole } from "../middleware/auth.js";
import {
  submitBid,
  getBidsForRequest,
  acceptBid,
  withdrawBid,
  getDriverBids
} from "../controllers/biddingController.js";

const router = express.Router();

router.post("/requests/:id/bids", verifyuser, requireRole("driver"), submitBid);
router.get("/requests/:id/bids", verifyuser, getBidsForRequest);
router.post("/bids/:bidId/accept", verifyuser, acceptBid);
router.delete("/bids/:id", verifyuser, requireRole("driver"), withdrawBid);
router.get("/my-bids", verifyuser, requireRole("driver"), getDriverBids);

export default router;
