import { BiddingService } from "../application/services/BiddingService.js";
import { notifyBidSubmitted, notifyBidAccepted, notifyBidRejected } from "../realtime/socketServer.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import RideBidModel from "../models/ride/RideBid.js";
import RideRequestModel from "../models/ride/RideRequest.js";

const service = new BiddingService();

export const submitBid = async (req, res, next) => {
  try {
    const result = await service.submitBid({
      rideRequestId: req.params.id,
      driverId: req.user.driverId,
      ...req.body
    });

    // Get request to notify rider
    const request = await RideRequestModel.findById(req.params.id);
    
    notifyBidSubmitted(request.rider_id, {
      bidId: result.bidId,
      requestId: req.params.id,
      amount: result.bidAmount,
      driverId: req.user.driverId
    });

    res.status(201).json(ApiResponse.success(result));
  } catch (err) {
    next(err);
  }
};

export const getBidsForRequest = async (req, res, next) => {
  try {
    const bids = await service.getBidsForRequest(req.params.id, req.user.id);
    res.json(ApiResponse.success(bids));
  } catch (err) {
    next(err);
  }
};

export const acceptBid = async (req, res, next) => {
  try {
    const result = await service.acceptBid(req.params.bidId, req.user.id);

    // Notify accepted driver
    notifyBidAccepted(result.driverId, {
      bidId: req.params.bidId,
      accepted: true
    });

    // Notify rejected drivers
    const allBids = await RideBidModel.find({
      ride_request_id: req.params.requestId,
      status: 'rejected'
    });
    
    allBids.forEach(bid => {
      notifyBidRejected(bid.driver_id, req.params.requestId);
    });

    res.json(ApiResponse.success(result));
  } catch (err) {
    next(err);
  }
};

export const withdrawBid = async (req, res, next) => {
  try {
    const result = await service.withdrawBid(req.params.id, req.user.driverId);
    res.json(ApiResponse.success(result));
  } catch (err) {
    next(err);
  }
};

export const getDriverBids = async (req, res, next) => {
  try {
    const bids = await service.getDriverBids(req.user.driverId);
    res.json(ApiResponse.success(bids));
  } catch (err) {
    next(err);
  }
};
