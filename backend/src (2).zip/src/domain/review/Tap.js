export class Tap {
  constructor({ key, category, pointValue }) {
    this.key = key;                
    this.category = category;      
    this.pointValue = pointValue;
  }
}
