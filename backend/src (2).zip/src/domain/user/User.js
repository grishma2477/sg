export class User {
  constructor({ id, role, status }) {
    this.id = id;
    this.role = role;      
    this.status = status;  
  }
}
