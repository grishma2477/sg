export class UserProfile {
  constructor({ userId, firstName, lastName }) {
    this.userId = userId;
    this.firstName = firstName;
    this.lastName = lastName;
  }
}
