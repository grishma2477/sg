import { SafetyImpact } from "../../domain/safety/SafetyImpact.js";

export class SafetyImpactFactory {
  static create({ rating, taps }) {
    const starImpact = rating.stars >= 4 ? 2 : rating.stars <= 2 ? -5 : 0;

    const positiveImpact = taps
      .filter(t => t.category === "positive")
      .reduce((s, t) => s + t.pointValue, 0);

    const negativeImpact = taps
      .filter(t => t.category === "negative")
      .reduce((s, t) => s + t.pointValue, 0);

    const totalImpact =
      starImpact + positiveImpact + negativeImpact;

    return new SafetyImpact({
      starImpact,
      positiveImpact,
      negativeImpact,
      totalImpact,
      breakdown: { starImpact, positiveImpact, negativeImpact }
    });
  }
}
