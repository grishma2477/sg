// import redis from "../../infrastructure/redisClient.js";

// export class RideCompletionService {
//   async completeRide({ rideSummary }) {
//     if (rideSummary.status !== "completed") {
//       throw new Error("Ride is not completed");
//     }

//     if (!rideSummary.isPaid) {
//       throw new Error("Ride is not paid");
//     }

//     await redis.set(
//       `pending_review:${rideSummary.riderId}`,
//       rideSummary.rideId,
//       "EX",
//       60 * 60 * 24 // 24 hours
//     );

//     return {
//       rideId: rideSummary.rideId,
//       riderId: rideSummary.riderId,
//       driverId: rideSummary.driverId,
//       completedAt: rideSummary.completedAt
//     };
//   }
// }


import redis from "../../infrastructure/redisClient.js";
import { withTransaction } from "../../infrastructure/transactions/withTransaction.js";
import RideModel from "../../models/ride/Ride.js";
import DriverModel from "../../models/driver/Driver.js";
import Payment from "../../models/finance/payment/Payment.js";
import { LedgerService } from "./LedgerService.js";
import { AppError } from "../../utils/AppError.js";
import { notifyRideStatusChange } from "../../realtime/socketServer.js";

export class RideCompletionService {

  async completeRide({ rideId }) {
    return await withTransaction(async (client) => {

      const ride = await RideModel.findById(rideId, client);
      if (!ride) {
        throw new AppError("RIDE_NOT_FOUND", 404);
      }

      if (ride.status !== "started") {
        throw new AppError("RIDE_NOT_IN_PROGRESS", 400);
      }

      const payment = await Payment.findOne(
        { ride_id: rideId },
        client
      );

      if (!payment) {
        throw new AppError("PAYMENT_NOT_FOUND", 404);
      }

      if (payment.status !== "authorized") {
        throw new AppError("PAYMENT_NOT_AUTHORIZED", 400);
      }

      const driver = await DriverModel.findById(ride.driver_id, client);
      if (!driver) {
        throw new AppError("DRIVER_NOT_FOUND", 404);
      }

      // 1️⃣ SETTLE LEDGER (Escrow → Driver + Revenue)
      await LedgerService.settlePayment({
        rideId,
        driverId: driver.user_id,
        totalAmount: parseFloat(payment.amount_authorized),
        platformFee: parseFloat(payment.amount_authorized) * 0.10 // TODO dynamic commission
      });

      // 2️⃣ Update Payment
      await Payment.updateOne(
        { id: payment.id },
        {
          status: "completed",
          amount_captured: payment.amount_authorized,
          completed_at: new Date()
        },
        client
      );

      // 3️⃣ Update Ride
      const updatedRide = await RideModel.findByIdAndUpdate(
        rideId,
        {
          status: "completed",
          completed_at: new Date()
        },
        client
      );

      // 4️⃣ Set Redis Review Flags
      await redis.set(
        `pending_review:${ride.rider_id}`,
        rideId,
        "EX",
        60 * 60 * 24 * 7
      );

      await redis.set(
        `pending_review:${driver.user_id}`,
        rideId,
        "EX",
        60 * 60 * 24 * 7
      );

      return {
        ride: updatedRide,
        payment
      };
    }).then((result) => {

      // 5️⃣ SOCKET EMIT (Outside transaction)
      notifyRideStatusChange(
        result.ride.rider_id,
        result.ride.driver_id,
        "completed",
        result.ride
      );

      return result;
    });
  }
}