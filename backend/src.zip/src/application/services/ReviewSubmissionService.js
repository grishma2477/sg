import { ReviewEligibilityValidator } from "../validators/ReviewEligibilityValidator.js";
import { RatingTapValidator } from "../validators/RatingTapValidator.js";
import { ReviewFactory } from "../factories/ReviewFactory.js";

import { withTransaction } from "../../infrastructure/transactions/withTransaction.js";
import redis from "../../infrastructure/redisClient.js";

import ReviewModel from "../../models/review/Review.js";

export class ReviewSubmissionService {
  async submit({ rideSummary, userReviewState, rating, taps }) {
    // Validate business rules
    ReviewEligibilityValidator.validate({ rideSummary, userReviewState });
    RatingTapValidator.validate(rating, taps);

    // Create domain object
    const review = ReviewFactory.create({
      rideId: rideSummary.rideId,
      reviewerId: rideSummary.riderId,
      driverId: rideSummary.driverId,
      rating,
      taps
    });

    // TRANSACTION: persist review safely
    await withTransaction(async (client) => {
      await ReviewModel.create(
        {
          id: review.id,
          ride_id: review.rideId,
          reviewer_id: review.reviewerId,
          driver_id: review.driverId,
          stars: review.rating.stars,
          taps: JSON.stringify(review.taps),
          created_at: review.createdAt
        },
        client
      );
    });

    // CLEAR REDIS FLAG (after review is done/given )
    await redis.del(`pending_review:${review.reviewerId}`);

    return review;
  }
}
