export class DriverStateUpdateService {
  apply({ driverSafetyState, safetyImpact }) {
    const newPoints =
      driverSafetyState.points.value + safetyImpact.totalImpact;

    return {
      ...driverSafetyState,
      points: driverSafetyState.points.constructor(newPoints),
      lastUpdatedAt: new Date()
    };
  }
}
