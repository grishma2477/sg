import { SafetyCalculationService } from "../application/services/SafetyCalculationService.js";
import { DriverStateUpdateService } from "../application/services/DriverStateUpdateService.js";
import { AuditService } from "../application/services/AuditService.js";

export async function runSafetyWorker(review) {
  const safety = new SafetyCalculationService().calculate(review);

  await new DriverStateUpdateService().apply(safety);

  await new AuditService().record(review, safety);
}
