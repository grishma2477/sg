export const Currency = Object.freeze({
  USD: "USD",
  INR: "INR",
  NPR: "NPR",
  AUD: "AUD",
});