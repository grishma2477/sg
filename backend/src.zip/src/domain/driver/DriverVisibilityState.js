export class DriverVisibilityState {
  constructor({ driverId, multiplier, isRestricted }) {
    this.driverId = driverId;
    this.multiplier = multiplier;
    this.isRestricted = isRestricted;
  }
}
