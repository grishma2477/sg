export class Driver {
  constructor({ id, userId, status }) {
    this.id = id;
    this.userId = userId;
    this.status = status; 
  }
}
