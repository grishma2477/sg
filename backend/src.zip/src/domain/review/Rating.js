import { RatingValue } from "../shared/valueObjects/RatingValue.js";

export class Rating {
  constructor(ratingValue) {
    this.value = ratingValue; 
  }
}
